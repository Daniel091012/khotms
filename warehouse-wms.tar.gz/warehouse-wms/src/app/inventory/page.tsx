import { prisma } from '@/lib/prisma'
import { BarChart3, AlertTriangle, Package } from 'lucide-react'
import { formatNumber } from '@/lib/utils'

export default async function InventoryPage() {
  const inventory = await prisma.inventory.findMany({
    where: {
      quantity: { gt: 0 },
    },
    include: {
      product: {
        include: { unit: true },
      },
      location: {
        include: {
          zone: {
            include: { warehouse: true },
          },
        },
      },
    },
    orderBy: { updatedAt: 'desc' },
    take: 100,
  })

  // Group by product for summary
  const productSummary = inventory.reduce((acc, item) => {
    const key = item.productId
    if (!acc[key]) {
      acc[key] = {
        product: item.product,
        totalQty: 0,
        locations: 0,
      }
    }
    acc[key].totalQty += Number(item.quantity)
    acc[key].locations += 1
    return acc
  }, {} as Record<number, any>)

  const summaryList = Object.values(productSummary)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <BarChart3 className="w-8 h-8 text-primary-600" />
          Tồn kho
        </h1>
        <p className="text-slate-500 mt-1">Theo dõi tồn kho theo vị trí và lô hàng</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Sản phẩm có tồn</p>
              <p className="text-2xl font-bold">{summaryList.length}</p>
            </div>
          </div>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Tổng vị trí lưu</p>
              <p className="text-2xl font-bold">{inventory.length}</p>
            </div>
          </div>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Cảnh báo tồn thấp</p>
              <p className="text-2xl font-bold">
                {summaryList.filter(s => Number(s.product.minStock) > 0 && s.totalQty < Number(s.product.minStock)).length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="card">
        <div className="p-4 border-b border-slate-100">
          <h2 className="font-semibold">Chi tiết tồn kho theo vị trí</h2>
        </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Sản phẩm</th>
                <th>SKU</th>
                <th>Kho</th>
                <th>Vị trí</th>
                <th>Số lô</th>
                <th className="text-right">Tồn</th>
                <th className="text-right">Đã giữ</th>
                <th className="text-right">Khả dụng</th>
              </tr>
            </thead>
            <tbody>
              {inventory.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    Chưa có dữ liệu tồn kho
                  </td>
                </tr>
              ) : (
                inventory.map((item) => {
                  const available = Number(item.quantity) - Number(item.reservedQuantity)
                  const isLow = Number(item.product.minStock) > 0 && available < Number(item.product.minStock)
                  
                  return (
                    <tr key={item.id} className={isLow ? 'bg-amber-50' : ''}>
                      <td className="font-medium">{item.product.name}</td>
                      <td className="font-mono text-sm text-primary-600">{item.product.sku}</td>
                      <td>{item.location.zone.warehouse.name}</td>
                      <td>
                        <span className="font-mono text-sm">{item.location.code}</span>
                      </td>
                      <td className="text-sm text-slate-500">
                        {item.lotNumber || '—'}
                      </td>
                      <td className="text-right font-medium">
                        {formatNumber(item.quantity)} {item.product.unit.code}
                      </td>
                      <td className="text-right text-slate-500">
                        {formatNumber(item.reservedQuantity)}
                      </td>
                      <td className={`text-right font-semibold ${isLow ? 'text-amber-600' : 'text-emerald-600'}`}>
                        {formatNumber(available)}
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
