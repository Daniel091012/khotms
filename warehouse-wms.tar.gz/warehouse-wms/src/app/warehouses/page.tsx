import { prisma } from '@/lib/prisma'
import { Warehouse, Plus, MapPin } from 'lucide-react'
import Link from 'next/link'

export default async function WarehousesPage() {
  const warehouses = await prisma.warehouse.findMany({
    where: { isActive: true },
    include: {
      manager: true,
      _count: {
        select: { zones: true },
      },
    },
    orderBy: { name: 'asc' },
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Warehouse className="w-8 h-8 text-primary-600" />
            Kho & Vị trí
          </h1>
          <p className="text-slate-500 mt-1">Quản lý kho vật lý, khu vực và vị trí lưu trữ</p>
        </div>
        <Link href="/warehouses/new" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Thêm kho
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {warehouses.length === 0 ? (
          <div className="col-span-full card p-12 text-center text-slate-400">
            <Warehouse className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <p>Chưa có kho nào được thiết lập</p>
          </div>
        ) : (
          warehouses.map((wh) => (
            <Link
              key={wh.id}
              href={`/warehouses/${wh.id}`}
              className="card p-6 hover:shadow-lg hover:border-primary-200 transition-all duration-300 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center group-hover:bg-primary-600 group-hover:text-white transition-colors">
                  <Warehouse className="w-6 h-6" />
                </div>
                <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded">
                  {wh.code}
                </span>
              </div>
              
              <h3 className="font-semibold text-lg group-hover:text-primary-600 transition-colors">
                {wh.name}
              </h3>
              
              {wh.address && (
                <p className="text-sm text-slate-500 mt-1 flex items-start gap-1">
                  <MapPin className="w-4 h-4 mt-0.5 shrink-0" />
                  {wh.address}
                </p>
              )}
              
              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-sm">
                <span className="text-slate-500">
                  {wh._count.zones} khu vực
                </span>
                {wh.manager && (
                  <span className="text-slate-600">
                    QL: {wh.manager.fullName}
                  </span>
                )}
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  )
}
