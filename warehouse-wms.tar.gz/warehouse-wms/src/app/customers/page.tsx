import { Users, Plus } from 'lucide-react'
import Link from 'next/link'

export default function CustomersPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Users className="w-8 h-8 text-primary-600" />
            Khách hàng
          </h1>
          <p className="text-slate-500 mt-1">Quản lý thông tin khách hàng</p>
        </div>
        <Link href="/customers/new" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Thêm khách hàng
        </Link>
      </div>

      <div className="card p-12 text-center text-slate-400">
        <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>Module khách hàng đang được phát triển</p>
        <p className="text-sm mt-2">Bạn có thể mở rộng từ schema Prisma đã có</p>
      </div>
    </div>
  )
}
