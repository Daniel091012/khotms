import { motion } from 'framer-motion'
import { Package, Warehouse, ArrowDownToLine, ArrowUpFromLine, AlertTriangle, TrendingUp } from 'lucide-react'
import { prisma } from '@/lib/prisma'

async function getDashboardStats() {
  const [
    productCount,
    warehouseCount,
    lowStockCount,
    recentReceipts,
    recentIssues,
  ] = await Promise.all([
    prisma.product.count({ where: { isActive: true } }),
    prisma.warehouse.count({ where: { isActive: true } }),
    prisma.product.count({
      where: {
        isActive: true,
        inventoryPolicy: { in: ['stocked', 'consumable'] },
      },
    }),
    prisma.goodsReceipt.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: { warehouse: true },
    }),
    prisma.goodsIssue.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: { warehouse: true },
    }),
  ])

  return {
    productCount,
    warehouseCount,
    lowStockCount,
    recentReceipts,
    recentIssues,
  }
}

export default async function DashboardPage() {
  const stats = await getDashboardStats()

  const statCards = [
    {
      title: 'Tổng sản phẩm',
      value: stats.productCount,
      icon: Package,
      color: 'bg-blue-500',
      change: '+12%',
    },
    {
      title: 'Kho hoạt động',
      value: stats.warehouseCount,
      icon: Warehouse,
      color: 'bg-emerald-500',
      change: 'Ổn định',
    },
    {
      title: 'Phiếu nhập gần đây',
      value: stats.recentReceipts.length,
      icon: ArrowDownToLine,
      color: 'bg-violet-500',
      change: 'Hôm nay',
    },
    {
      title: 'Phiếu xuất gần đây',
      value: stats.recentIssues.length,
      icon: ArrowUpFromLine,
      color: 'bg-orange-500',
      change: 'Hôm nay',
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500 mt-1">Tổng quan hệ thống quản lý kho</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-slate-500">Hôm nay</p>
          <p className="font-semibold">
            {new Date().toLocaleDateString('vi-VN', {
              weekday: 'long',
              day: 'numeric',
              month: 'long',
              year: 'numeric',
            })}
          </p>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="card p-6 hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-500 font-medium">{stat.title}</p>
                  <p className="text-3xl font-bold mt-2">{stat.value}</p>
                  <p className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    {stat.change}
                  </p>
                </div>
                <div className={`${stat.color} p-3 rounded-xl text-white`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Receipts */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="card"
        >
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-semibold flex items-center gap-2">
              <ArrowDownToLine className="w-5 h-5 text-emerald-500" />
              Phiếu nhập gần đây
            </h2>
            <a href="/receipts" className="text-sm text-primary-600 hover:underline">
              Xem tất cả
            </a>
          </div>
          <div className="divide-y divide-slate-100">
            {stats.recentReceipts.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                Chưa có phiếu nhập nào
              </div>
            ) : (
              stats.recentReceipts.map((receipt) => (
                <div key={receipt.id} className="p-4 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{receipt.code}</p>
                      <p className="text-sm text-slate-500">{receipt.warehouse.name}</p>
                    </div>
                    <div className="text-right">
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                        receipt.status === 'completed' 
                          ? 'bg-emerald-100 text-emerald-700'
                          : receipt.status === 'draft'
                          ? 'bg-slate-100 text-slate-600'
                          : 'bg-amber-100 text-amber-700'
                      }`}>
                        {receipt.status}
                      </span>
                      <p className="text-xs text-slate-400 mt-1">
                        {new Date(receipt.receiptDate).toLocaleDateString('vi-VN')}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>

        {/* Recent Issues */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="card"
        >
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-semibold flex items-center gap-2">
              <ArrowUpFromLine className="w-5 h-5 text-orange-500" />
              Phiếu xuất gần đây
            </h2>
            <a href="/issues" className="text-sm text-primary-600 hover:underline">
              Xem tất cả
            </a>
          </div>
          <div className="divide-y divide-slate-100">
            {stats.recentIssues.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                Chưa có phiếu xuất nào
              </div>
            ) : (
              stats.recentIssues.map((issue) => (
                <div key={issue.id} className="p-4 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{issue.code}</p>
                      <p className="text-sm text-slate-500">{issue.purpose}</p>
                    </div>
                    <div className="text-right">
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                        issue.status === 'completed' 
                          ? 'bg-emerald-100 text-emerald-700'
                          : issue.status === 'draft'
                          ? 'bg-slate-100 text-slate-600'
                          : 'bg-amber-100 text-amber-700'
                      }`}>
                        {issue.status}
                      </span>
                      <p className="text-xs text-slate-400 mt-1">
                        {new Date(issue.issueDate).toLocaleDateString('vi-VN')}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="card p-6"
      >
        <h2 className="font-semibold mb-4">Thao tác nhanh</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { href: '/receipts/new', label: 'Tạo phiếu nhập', icon: ArrowDownToLine, color: 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100' },
            { href: '/issues/new', label: 'Tạo phiếu xuất', icon: ArrowUpFromLine, color: 'bg-orange-50 text-orange-600 hover:bg-orange-100' },
            { href: '/products/new', label: 'Thêm sản phẩm', icon: Package, color: 'bg-blue-50 text-blue-600 hover:bg-blue-100' },
            { href: '/inventory', label: 'Kiểm tra tồn', icon: BarChart3, color: 'bg-violet-50 text-violet-600 hover:bg-violet-100' },
          ].map((action) => {
            const Icon = action.icon
            return (
              <a
                key={action.href}
                href={action.href}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl transition-all duration-200 ${action.color}`}
              >
                <Icon className="w-6 h-6" />
                <span className="text-sm font-medium">{action.label}</span>
              </a>
            )
          })}
        </div>
      </motion.div>
    </div>
  )
}
