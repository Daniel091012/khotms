import { prisma } from '@/lib/prisma'
import { Package, Plus, Search } from 'lucide-react'
import Link from 'next/link'
import { formatNumber } from '@/lib/utils'
import ProductTable from '@/components/ProductTable'

export default async function ProductsPage() {
  const products = await prisma.product.findMany({
    where: { isActive: true },
    include: {
      unit: true,
      category: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Package className="w-8 h-8 text-primary-600" />
            Sản phẩm
          </h1>
          <p className="text-slate-500 mt-1">Quản lý danh mục sản phẩm và SKU</p>
        </div>
        <Link href="/products/new" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Thêm sản phẩm
        </Link>
      </div>

      <div className="card">
        <div className="p-4 border-b border-slate-100 flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Tìm kiếm theo SKU, tên sản phẩm..."
              className="input pl-10"
            />
          </div>
          <select className="input w-40">
            <option value="">Tất cả loại</option>
            <option value="goods">Hàng hóa</option>
            <option value="component">Linh kiện</option>
            <option value="finished">Thành phẩm</option>
          </select>
          <select className="input w-40">
            <option value="">Tất cả chính sách</option>
            <option value="stocked">Lưu kho</option>
            <option value="consumable">Tiêu hao</option>
            <option value="non_stock">Không lưu kho</option>
          </select>
        </div>

        <ProductTable products={products} />
      </div>
    </div>
  )
}
