import { prisma } from '@/lib/prisma'
import { ArrowUpFromLine, Plus } from 'lucide-react'
import Link from 'next/link'
import { formatDate } from '@/lib/utils'

const purposeLabels: Record<string, string> = {
  sale: 'Xuất bán',
  inspection: 'Xuất kiểm định',
  installation: 'Xuất lắp đặt',
  exchange: 'Xuất đổi',
  production: 'Xuất sản xuất',
  loan: 'Xuất cho mượn',
  consumption: 'Xuất tiêu hao',
}

const statusColors: Record<string, string> = {
  draft: 'bg-slate-100 text-slate-600',
  confirmed: 'bg-blue-100 text-blue-700',
  partial: 'bg-amber-100 text-amber-700',
  completed: 'bg-emerald-100 text-emerald-700',
  cancelled: 'bg-red-100 text-red-700',
}

export default async function IssuesPage() {
  const issues = await prisma.goodsIssue.findMany({
    include: {
      warehouse: true,
      salesOrder: { include: { customer: true } },
      _count: { select: { items: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ArrowUpFromLine className="w-8 h-8 text-orange-600" />
            Xuất kho
          </h1>
          <p className="text-slate-500 mt-1">Phiếu xuất kho theo các mục đích</p>
        </div>
        <Link href="/issues/new" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Tạo phiếu xuất
        </Link>
      </div>

      <div className="card">
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Số phiếu</th>
                <th>Mục đích</th>
                <th>Kho</th>
                <th>Khách hàng / Đối tác</th>
                <th>Ngày xuất</th>
                <th>Số dòng</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {issues.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    Chưa có phiếu xuất nào
                  </td>
                </tr>
              ) : (
                issues.map((issue) => (
                  <tr key={issue.id} className="hover:bg-slate-50 cursor-pointer">
                    <td className="font-mono font-medium text-primary-600">{issue.code}</td>
                    <td>{purposeLabels[issue.purpose] || issue.purpose}</td>
                    <td>{issue.warehouse.name}</td>
                    <td className="text-sm">
                      {issue.salesOrder?.customer?.name || '—'}
                    </td>
                    <td>{formatDate(issue.issueDate)}</td>
                    <td className="text-center">{issue._count.items}</td>
                    <td>
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${statusColors[issue.status]}`}>
                        {issue.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
