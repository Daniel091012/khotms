'use client'

import { useState, useTransition } from 'react'
import { motion } from 'framer-motion'
import { createGoodsIssue } from '../actions/issue-actions'
import { useRouter } from 'next/navigation'

export default function NewIssuePage() {
  const [isPending, startTransition] = useTransition()
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const router = useRouter()

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)

    startTransition(async () => {
      const result = await createGoodsIssue(formData)
      if (result.error) {
        setMessage({ type: 'error', text: result.error })
      } else {
        setMessage({ type: 'success', text: `Đã tạo phiếu ${result.code}` })
        setTimeout(() => router.push('/issues'), 1500)
      }
    })
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-3xl mx-auto space-y-6"
    >
      <div>
        <h1 className="text-3xl font-bold">Tạo phiếu xuất kho</h1>
        <p className="text-slate-500 mt-1">Xuất bán, kiểm định, lắp đặt, tiêu hao...</p>
      </div>

      <form onSubmit={handleSubmit} className="card p-6 space-y-5">
        {message && (
          <div className={`p-3 rounded-lg text-sm ${message.type === 'error' ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'}`}>
            {message.text}
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Số phiếu *</label>
            <input name="code" required className="input" placeholder="PX-2026-001" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Mục đích *</label>
            <select name="purpose" required className="input">
              <option value="sale">Xuất bán</option>
              <option value="inspection">Xuất đi kiểm định</option>
              <option value="installation">Xuất đi lắp đặt</option>
              <option value="exchange">Xuất đi đổi</option>
              <option value="production">Xuất linh kiện sản xuất</option>
              <option value="loan">Xuất cho khách mượn</option>
              <option value="consumption">Xuất tiêu hao nội bộ</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Kho ID *</label>
            <input name="warehouseId" type="number" required className="input" placeholder="1" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Ngày xuất *</label>
            <input name="issueDate" type="date" required className="input" defaultValue={new Date().toISOString().slice(0, 10)} />
          </div>
        </div>

        <div className="border-t pt-5">
          <h3 className="font-semibold mb-3">Dòng hàng</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Product ID *</label>
              <input name="productId" type="number" required className="input" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Location ID *</label>
              <input name="locationId" type="number" required className="input" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Số lượng *</label>
              <input name="quantity" type="number" step="0.001" required className="input" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Số lô</label>
              <input name="lotNumber" className="input" />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Ghi chú</label>
          <textarea name="note" className="input" rows={2} />
        </div>

        <div className="flex gap-3 pt-2">
          <button type="submit" disabled={isPending} className="btn-primary">
            {isPending ? 'Đang tạo...' : 'Tạo phiếu xuất'}
          </button>
          <button type="button" onClick={() => router.back()} className="btn-secondary">
            Hủy
          </button>
        </div>
      </form>
    </motion.div>
  )
}
