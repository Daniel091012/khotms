import { Settings } from 'lucide-react'

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Settings className="w-8 h-8 text-primary-600" />
          Cài đặt
        </h1>
        <p className="text-slate-500 mt-1">Cấu hình hệ thống</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="font-semibold mb-2">Đơn vị tính</h3>
          <p className="text-sm text-slate-500 mb-4">Quản lý đơn vị tính (PCS, BOX, KG...)</p>
          <button className="btn-secondary text-sm">Quản lý</button>
        </div>
        <div className="card p-6">
          <h3 className="font-semibold mb-2">Danh mục sản phẩm</h3>
          <p className="text-sm text-slate-500 mb-4">Cây danh mục phân cấp</p>
          <button className="btn-secondary text-sm">Quản lý</button>
        </div>
        <div className="card p-6">
          <h3 className="font-semibold mb-2">Nhà cung cấp</h3>
          <p className="text-sm text-slate-500 mb-4">Danh sách nhà cung cấp</p>
          <button className="btn-secondary text-sm">Quản lý</button>
        </div>
        <div className="card p-6">
          <h3 className="font-semibold mb-2">Nhân viên</h3>
          <p className="text-sm text-slate-500 mb-4">Phân quyền và nhân sự kho</p>
          <button className="btn-secondary text-sm">Quản lý</button>
        </div>
      </div>
    </div>
  )
}
