import { prisma } from '@/lib/prisma'
import { Truck, Plus } from 'lucide-react'
import Link from 'next/link'
import { formatDate } from '@/lib/utils'

export default async function TransfersPage() {
  const transfers = await prisma.stockTransfer.findMany({
    include: {
      fromWarehouse: true,
      toWarehouse: true,
      _count: { select: { items: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 30,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Truck className="w-8 h-8 text-primary-600" />
            Chuyển kho
          </h1>
          <p className="text-slate-500 mt-1">Quản lý phiếu chuyển kho giữa các kho</p>
        </div>
        <Link href="/transfers/new" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Tạo phiếu chuyển
        </Link>
      </div>

      <div className="card">
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Số phiếu</th>
                <th>Từ kho</th>
                <th>Đến kho</th>
                <th>Ngày chuyển</th>
                <th>Số dòng</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {transfers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-400">
                    Chưa có phiếu chuyển kho nào
                  </td>
                </tr>
              ) : (
                transfers.map((t) => (
                  <tr key={t.id}>
                    <td className="font-mono font-medium text-primary-600">{t.code}</td>
                    <td>{t.fromWarehouse.name}</td>
                    <td>{t.toWarehouse.name}</td>
                    <td>{formatDate(t.transferDate)}</td>
                    <td className="text-center">{t._count.items}</td>
                    <td>
                      <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-slate-100">
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
