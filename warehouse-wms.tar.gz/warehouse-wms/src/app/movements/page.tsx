import { prisma } from '@/lib/prisma'
import { History, ArrowDown, ArrowUp, RefreshCw } from 'lucide-react'
import { formatDate, formatNumber } from '@/lib/utils'

const typeConfig: Record<string, { label: string; icon: any; color: string }> = {
  receipt: { label: 'Nhập', icon: ArrowDown, color: 'text-emerald-600 bg-emerald-50' },
  issue: { label: 'Xuất', icon: ArrowUp, color: 'text-orange-600 bg-orange-50' },
  transfer_in: { label: 'Chuyển đến', icon: RefreshCw, color: 'text-blue-600 bg-blue-50' },
  transfer_out: { label: 'Chuyển đi', icon: RefreshCw, color: 'text-violet-600 bg-violet-50' },
  adjustment: { label: 'Điều chỉnh', icon: RefreshCw, color: 'text-slate-600 bg-slate-50' },
}

export default async function MovementsPage() {
  const movements = await prisma.stockMovement.findMany({
    include: {
      product: true,
      location: { include: { zone: { include: { warehouse: true } } } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <History className="w-8 h-8 text-primary-600" />
          Lịch sử biến động kho
        </h1>
        <p className="text-slate-500 mt-1">Sổ cái kho – mọi thay đổi tồn đều được ghi nhận</p>
      </div>

      <div className="card">
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Thời gian</th>
                <th>Loại</th>
                <th>Sản phẩm</th>
                <th>Kho / Vị trí</th>
                <th className="text-right">Số lượng</th>
                <th>Chứng từ</th>
              </tr>
            </thead>
            <tbody>
              {movements.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-400">
                    Chưa có biến động nào
                  </td>
                </tr>
              ) : (
                movements.map((m) => {
                  const cfg = typeConfig[m.movementType] || typeConfig.adjustment
                  const Icon = cfg.icon
                  const qty = Number(m.quantity)
                  return (
                    <tr key={m.id}>
                      <td className="text-sm text-slate-500 whitespace-nowrap">
                        {new Date(m.createdAt).toLocaleString('vi-VN')}
                      </td>
                      <td>
                        <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${cfg.color}`}>
                          <Icon className="w-3.5 h-3.5" />
                          {cfg.label}
                        </span>
                      </td>
                      <td>
                        <div>
                          <p className="font-medium">{m.product.name}</p>
                          <p className="text-xs text-slate-400 font-mono">{m.product.sku}</p>
                        </div>
                      </td>
                      <td className="text-sm">
                        {m.location.zone.warehouse.name}
                        <span className="text-slate-400"> / </span>
                        <span className="font-mono">{m.location.code}</span>
                      </td>
                      <td className={`text-right font-semibold ${qty >= 0 ? 'text-emerald-600' : 'text-orange-600'}`}>
                        {qty > 0 ? '+' : ''}{formatNumber(qty)}
                      </td>
                      <td className="text-sm text-slate-500">
                        {m.referenceType && m.referenceId ? `${m.referenceType} #${m.referenceId}` : '—'}
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
