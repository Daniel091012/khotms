'use server'

import { prisma } from '@/lib/prisma'
import { revalidatePath } from 'next/cache'

export async function createGoodsIssue(formData: FormData) {
  const code = formData.get('code') as string
  const purpose = formData.get('purpose') as any
  const warehouseId = parseInt(formData.get('warehouseId') as string)
  const issueDate = new Date(formData.get('issueDate') as string)
  const note = formData.get('note') as string || null

  const productId = parseInt(formData.get('productId') as string)
  const locationId = parseInt(formData.get('locationId') as string)
  const quantity = parseFloat(formData.get('quantity') as string)
  const lotNumber = (formData.get('lotNumber') as string) || ''

  if (!code || !warehouseId || !productId || !locationId || !quantity) {
    return { error: 'Thiếu thông tin bắt buộc' }
  }

  try {
    const issue = await prisma.goodsIssue.create({
      data: {
        code,
        purpose,
        warehouseId,
        issueDate,
        note,
        status: 'draft',
        items: {
          create: {
            productId,
            locationId,
            quantity,
            lotNumber: lotNumber || undefined,
          },
        },
      },
    })

    revalidatePath('/issues')
    return { success: true, id: issue.id, code: issue.code }
  } catch (e: any) {
    return { error: e.message || 'Lỗi khi tạo phiếu xuất' }
  }
}

export async function completeGoodsIssue(issueId: number) {
  const issue = await prisma.goodsIssue.findUnique({
    where: { id: issueId },
    include: { items: true },
  })

  if (!issue || issue.status === 'completed') {
    return { error: 'Phiếu không hợp lệ hoặc đã hoàn thành' }
  }

  for (const item of issue.items) {
    const inv = await prisma.inventory.findFirst({
      where: {
        locationId: item.locationId,
        productId: item.productId,
        lotNumber: item.lotNumber || '',
      },
    })

    const available = inv ? Number(inv.quantity) - Number(inv.reservedQuantity) : 0
    if (!inv || available < Number(item.quantity)) {
      return { error: `Không đủ tồn tại vị trí cho sản phẩm ID ${item.productId}` }
    }

    await prisma.inventory.update({
      where: { id: inv.id },
      data: { quantity: { decrement: item.quantity } },
    })

    await prisma.stockMovement.create({
      data: {
        warehouseId: issue.warehouseId,
        locationId: item.locationId,
        productId: item.productId,
        movementType: 'issue',
        quantity: -Number(item.quantity),
        lotNumber: item.lotNumber || undefined,
        referenceType: 'goods_issue',
        referenceId: issue.id,
        note: `Xuất kho phiếu ${issue.code}`,
      },
    })
  }

  await prisma.goodsIssue.update({
    where: { id: issueId },
    data: { status: 'completed' },
  })

  revalidatePath('/issues')
  revalidatePath('/inventory')
  return { success: true }
}
