'use server'

import { prisma } from '@/lib/prisma'
import { revalidatePath } from 'next/cache'

export async function createGoodsReceipt(formData: FormData) {
  const code = formData.get('code') as string
  const purpose = formData.get('purpose') as any
  const warehouseId = parseInt(formData.get('warehouseId') as string)
  const receiptDate = new Date(formData.get('receiptDate') as string)
  const note = formData.get('note') as string || null

  // Simple item (can be extended to multi-line)
  const productId = parseInt(formData.get('productId') as string)
  const locationId = parseInt(formData.get('locationId') as string)
  const quantity = parseFloat(formData.get('quantity') as string)
  const unitCost = parseFloat(formData.get('unitCost') as string || '0')
  const lotNumber = (formData.get('lotNumber') as string) || ''

  if (!code || !warehouseId || !productId || !locationId || !quantity) {
    return { error: 'Thiếu thông tin bắt buộc' }
  }

  try {
    const receipt = await prisma.goodsReceipt.create({
      data: {
        code,
        purpose,
        warehouseId,
        receiptDate,
        note,
        status: 'draft',
        items: {
          create: {
            productId,
            locationId,
            quantity,
            unitCost,
            lotNumber: lotNumber || undefined,
          },
        },
      },
    })

    revalidatePath('/receipts')
    return { success: true, id: receipt.id, code: receipt.code }
  } catch (e: any) {
    return { error: e.message || 'Lỗi khi tạo phiếu nhập' }
  }
}

export async function completeGoodsReceipt(receiptId: number) {
  const receipt = await prisma.goodsReceipt.findUnique({
    where: { id: receiptId },
    include: { items: true },
  })

  if (!receipt || receipt.status === 'completed') {
    return { error: 'Phiếu không hợp lệ hoặc đã hoàn thành' }
  }

  // Update inventory + create stock movements
  for (const item of receipt.items) {
    const existing = await prisma.inventory.findFirst({
      where: {
        locationId: item.locationId,
        productId: item.productId,
        lotNumber: item.lotNumber || '',
      },
    })

    if (existing) {
      await prisma.inventory.update({
        where: { id: existing.id },
        data: { quantity: { increment: item.quantity } },
      })
    } else {
      await prisma.inventory.create({
        data: {
          warehouseId: receipt.warehouseId,
          locationId: item.locationId,
          productId: item.productId,
          lotNumber: item.lotNumber || '',
          quantity: item.quantity,
          expiryDate: item.expiryDate,
        },
      })
    }

    await prisma.stockMovement.create({
      data: {
        warehouseId: receipt.warehouseId,
        locationId: item.locationId,
        productId: item.productId,
        movementType: 'receipt',
        quantity: item.quantity,
        lotNumber: item.lotNumber || undefined,
        referenceType: 'goods_receipt',
        referenceId: receipt.id,
        note: `Nhập kho phiếu ${receipt.code}`,
      },
    })
  }

  await prisma.goodsReceipt.update({
    where: { id: receiptId },
    data: { status: 'completed' },
  })

  revalidatePath('/receipts')
  revalidatePath('/inventory')
  return { success: true }
}
