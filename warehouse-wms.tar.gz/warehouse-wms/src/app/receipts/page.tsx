import { prisma } from '@/lib/prisma'
import { ArrowDownToLine, Plus } from 'lucide-react'
import Link from 'next/link'
import { formatDate } from '@/lib/utils'

const purposeLabels: Record<string, string> = {
  new_stock: 'Nhập mới',
  customer_return: 'Khách trả',
  inspection_return: 'Sau kiểm định',
  exchange: 'Nhập đổi',
  production: 'Nhập thành phẩm',
  loan_return: 'Trả hàng mượn',
}

const statusColors: Record<string, string> = {
  draft: 'bg-slate-100 text-slate-600',
  confirmed: 'bg-blue-100 text-blue-700',
  partial: 'bg-amber-100 text-amber-700',
  completed: 'bg-emerald-100 text-emerald-700',
  cancelled: 'bg-red-100 text-red-700',
}

export default async function ReceiptsPage() {
  const receipts = await prisma.goodsReceipt.findMany({
    include: {
      warehouse: true,
      supplier: true,
      customer: true,
      _count: { select: { items: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ArrowDownToLine className="w-8 h-8 text-emerald-600" />
            Nhập kho
          </h1>
          <p className="text-slate-500 mt-1">Phiếu nhập kho theo các mục đích</p>
        </div>
        <Link href="/receipts/new" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Tạo phiếu nhập
        </Link>
      </div>

      <div className="card">
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Số phiếu</th>
                <th>Mục đích</th>
                <th>Kho</th>
                <th>Đối tác</th>
                <th>Ngày nhập</th>
                <th>Số dòng</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {receipts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    Chưa có phiếu nhập nào
                  </td>
                </tr>
              ) : (
                receipts.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 cursor-pointer">
                    <td className="font-mono font-medium text-primary-600">{r.code}</td>
                    <td>{purposeLabels[r.purpose] || r.purpose}</td>
                    <td>{r.warehouse.name}</td>
                    <td className="text-sm">
                      {r.supplier?.name || r.customer?.name || '—'}
                    </td>
                    <td>{formatDate(r.receiptDate)}</td>
                    <td className="text-center">{r._count.items}</td>
                    <td>
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${statusColors[r.status]}`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
