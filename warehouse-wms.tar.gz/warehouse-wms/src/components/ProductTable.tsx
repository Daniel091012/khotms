'use client'

import { motion } from 'framer-motion'
import { Package } from 'lucide-react'
import { formatNumber } from '@/lib/utils'

interface Product {
  id: number
  sku: string
  name: string
  productType: string
  inventoryPolicy: string
  minStock: any
  costPrice: any
  unit: { name: string; code: string }
  category: { name: string } | null
}

export default function ProductTable({ products }: { products: Product[] }) {
  const typeLabels: Record<string, string> = {
    goods: 'Hàng hóa',
    component: 'Linh kiện',
    finished: 'Thành phẩm',
  }

  const policyLabels: Record<string, { label: string; color: string }> = {
    stocked: { label: 'Lưu kho', color: 'bg-emerald-100 text-emerald-700' },
    consumable: { label: 'Tiêu hao', color: 'bg-amber-100 text-amber-700' },
    non_stock: { label: 'Không lưu kho', color: 'bg-slate-100 text-slate-600' },
  }

  return (
    <div className="table-container">
      <table className="table">
        <thead>
          <tr>
            <th>SKU</th>
            <th>Tên sản phẩm</th>
            <th>Loại</th>
            <th>Chính sách tồn</th>
            <th>Đơn vị</th>
            <th>Tồn tối thiểu</th>
            <th>Giá vốn</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {products.length === 0 ? (
            <tr>
              <td colSpan={8} className="text-center py-12 text-slate-400">
                <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                Chưa có sản phẩm nào
              </td>
            </tr>
          ) : (
            products.map((product, index) => {
              const policy = policyLabels[product.inventoryPolicy] || policyLabels.stocked
              return (
                <motion.tr
                  key={product.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className="group"
                >
                  <td className="font-mono font-medium text-primary-600">{product.sku}</td>
                  <td>
                    <div>
                      <p className="font-medium">{product.name}</p>
                      {product.category && (
                        <p className="text-xs text-slate-400">{product.category.name}</p>
                      )}
                    </div>
                  </td>
                  <td>
                    <span className="text-sm">{typeLabels[product.productType]}</span>
                  </td>
                  <td>
                    <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${policy.color}`}>
                      {policy.label}
                    </span>
                  </td>
                  <td>{product.unit.code}</td>
                  <td className="text-right">{formatNumber(product.minStock)}</td>
                  <td className="text-right font-medium">
                    {formatNumber(product.costPrice, 0)} đ
                  </td>
                  <td>
                    <button className="text-sm text-primary-600 hover:underline opacity-0 group-hover:opacity-100 transition-opacity">
                      Chi tiết
                    </button>
                  </td>
                </motion.tr>
              )
            })
          )}
        </tbody>
      </table>
    </div>
  )
}
