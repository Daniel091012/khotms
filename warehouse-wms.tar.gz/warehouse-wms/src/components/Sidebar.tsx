'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion } from 'framer-motion'
import {
  LayoutDashboard,
  Package,
  Warehouse,
  ArrowDownToLine,
  ArrowUpFromLine,
  BarChart3,
  Settings,
  Users,
  Truck,
  History,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const menuItems = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/products', label: 'Sản phẩm', icon: Package },
  { href: '/warehouses', label: 'Kho & Vị trí', icon: Warehouse },
  { href: '/receipts', label: 'Nhập kho', icon: ArrowDownToLine },
  { href: '/issues', label: 'Xuất kho', icon: ArrowUpFromLine },
  { href: '/inventory', label: 'Tồn kho', icon: BarChart3 },
  { href: '/movements', label: 'Biến động', icon: History },
  { href: '/transfers', label: 'Chuyển kho', icon: Truck },
  { href: '/customers', label: 'Khách hàng', icon: Users },
  { href: '/settings', label: 'Cài đặt', icon: Settings },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-900 text-white flex flex-col z-50">
      <div className="p-6 border-b border-slate-800">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3"
        >
          <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center">
            <Warehouse className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-lg">WMS</h1>
            <p className="text-xs text-slate-400">Quản lý Kho</p>
          </div>
        </motion.div>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item, index) => {
          const Icon = item.icon
          const isActive = pathname === item.href || 
            (item.href !== '/' && pathname.startsWith(item.href))

          return (
            <motion.div
              key={item.href}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group',
                  isActive
                    ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/30'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                )}
              >
                <Icon className={cn(
                  'w-5 h-5 transition-transform group-hover:scale-110',
                  isActive && 'scale-110'
                )} />
                <span className="font-medium">{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="ml-auto w-1.5 h-1.5 bg-white rounded-full"
                  />
                )}
              </Link>
            </motion.div>
          )
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 px-4 py-2">
          <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center text-sm font-medium">
            A
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">Admin</p>
            <p className="text-xs text-slate-400">Quản trị viên</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
