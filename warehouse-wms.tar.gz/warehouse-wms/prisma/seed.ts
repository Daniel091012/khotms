import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Units
  const unitPcs = await prisma.unit.upsert({
    where: { code: 'PCS' },
    update: {},
    create: { code: 'PCS', name: 'Cái' },
  })

  const unitBox = await prisma.unit.upsert({
    where: { code: 'BOX' },
    update: {},
    create: { code: 'BOX', name: 'Hộp' },
  })

  // Categories
  const catElectronics = await prisma.category.upsert({
    where: { code: 'ELEC' },
    update: {},
    create: { code: 'ELEC', name: 'Điện tử' },
  })

  // Warehouse
  const warehouse = await prisma.warehouse.upsert({
    where: { code: 'WH-HN' },
    update: {},
    create: {
      code: 'WH-HN',
      name: 'Kho Hà Nội',
      address: 'Số 123 Đường ABC, Hà Nội',
    },
  })

  // Zone
  const zone = await prisma.zone.upsert({
    where: { warehouseId_code: { warehouseId: warehouse.id, code: 'A' } },
    update: {},
    create: {
      warehouseId: warehouse.id,
      code: 'A',
      name: 'Khu A - Lưu trữ',
      zoneType: 'storage',
    },
  })

  // Locations
  await prisma.location.upsert({
    where: { zoneId_code: { zoneId: zone.id, code: 'A-01-01' } },
    update: {},
    create: {
      zoneId: zone.id,
      code: 'A-01-01',
      aisle: '01',
      rack: '01',
      bin: '01',
      locationType: 'storage',
    },
  })

  // Products
  const product1 = await prisma.product.upsert({
    where: { sku: 'SKU-001' },
    update: {},
    create: {
      sku: 'SKU-001',
      name: 'Laptop Dell Latitude',
      categoryId: catElectronics.id,
      unitId: unitPcs.id,
      productType: 'goods',
      inventoryPolicy: 'stocked',
      costPrice: 15000000,
      minStock: 5,
    },
  })

  const product2 = await prisma.product.upsert({
    where: { sku: 'SKU-002' },
    update: {},
    create: {
      sku: 'SKU-002',
      name: 'Chuột không dây Logitech',
      categoryId: catElectronics.id,
      unitId: unitPcs.id,
      productType: 'goods',
      inventoryPolicy: 'stocked',
      costPrice: 350000,
      minStock: 20,
    },
  })

  console.log('✅ Seed completed!')
  console.log(`Created: Warehouse ${warehouse.name}, Products ${product1.sku}, ${product2.sku}`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
