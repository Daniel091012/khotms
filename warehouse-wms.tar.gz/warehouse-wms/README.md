# Warehouse Management System (WMS)

Hệ thống quản lý kho đầy đủ dựa trên DBML diagram, được xây dựng với:

- **Next.js 14** (App Router)
- **Prisma** + PostgreSQL
- **Tailwind CSS** + **Framer Motion** (animation mượt)

## Tính năng chính

- Dashboard tổng quan với thống kê realtime
- Quản lý sản phẩm (SKU, loại hàng, chính sách tồn)
- Quản lý kho, khu vực (zones), vị trí (locations)
- Phiếu nhập kho theo nhiều mục đích
- Phiếu xuất kho theo nhiều mục đích
- Theo dõi tồn kho theo vị trí và lô
- Chuyển kho
- Animation mượt mà trên toàn bộ UI

## Cài đặt

```bash
# 1. Cài dependencies
npm install

# 2. Tạo file .env
cp .env.example .env
# Chỉnh DATABASE_URL trong .env

# 3. Generate Prisma client & push schema
npx prisma generate
npx prisma db push

# 4. (Tùy chọn) Seed dữ liệu mẫu
npm run db:seed

# 5. Chạy development
npm run dev
```

## Cấu trúc Database

Schema Prisma đã được chuyển đổi đầy đủ từ DBML, bao gồm:

- Units, Categories, Suppliers, Customers, Employees
- Warehouses → Zones → Locations
- Products + ProductSuppliers + BOM
- Purchase Orders, Goods Receipts
- Sales Orders, Goods Issues
- Inventory, Stock Transfers, Stock Movements
- Production Orders, Inspection, Installation, Loan, Consumption
- Waybills (vận đơn)

## Giao diện

- Sidebar cố định với animation
- Cards với hover effects
- Tables với staggered animation
- Responsive design
- Màu sắc phân biệt rõ ràng theo loại nghiệp vụ

## Mở rộng

Bạn có thể tiếp tục phát triển:

1. Form tạo/sửa đầy đủ cho từng module
2. Server Actions để xử lý nghiệp vụ nhập/xuất
3. Logic cập nhật tồn kho tự động
4. Báo cáo và biểu đồ
5. Tích hợp API vận chuyển
6. Authentication & phân quyền

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | Next.js 14, React 18, Tailwind CSS, Framer Motion |
| Backend | Next.js Server Components & Server Actions |
| Database | PostgreSQL + Prisma ORM |
| Icons | Lucide React |
